import {clamp} from './ball.js';
export class SpinControl {
  constructor(canvas,onChange){this.canvas=canvas;this.value={x:0,y:0};this.onChange=onChange;this.active=null;
    canvas.addEventListener('pointerdown',e=>{this.active=e.pointerId;canvas.setPointerCapture(e.pointerId);this.setFromPointer(e);});
    canvas.addEventListener('pointermove',e=>{if(this.active===e.pointerId)this.setFromPointer(e);});
    canvas.addEventListener('pointerup',()=>this.active=null);canvas.addEventListener('pointercancel',()=>this.active=null);
    canvas.addEventListener('keydown',e=>{const keys={ArrowLeft:[-.1,0],ArrowRight:[.1,0],ArrowUp:[0,.1],ArrowDown:[0,-.1]};if(keys[e.key]){e.preventDefault();const [x,y]=keys[e.key];this.set(this.value.x+x,this.value.y+y);}if(e.key==='Home')this.set(0,0);});this.draw();
  }
  setFromPointer(e){const r=this.canvas.getBoundingClientRect();this.set((e.clientX-r.left-r.width/2)/(r.width*.34),-(e.clientY-r.top-r.height/2)/(r.height*.34));}
  set(x,y){const l=Math.hypot(x,y),f=l>1?1/l:1;this.value={x:x*f,y:y*f};this.draw();this.onChange?.(this.value);}
  reset(){this.set(0,0);}
  draw(){const c=this.canvas.getContext('2d'),w=this.canvas.width,h=this.canvas.height,r=w*.36;c.clearRect(0,0,w,h);c.save();c.translate(w/2,h/2);
    const g=c.createRadialGradient(-r*.4,-r*.4,1,0,0,r);g.addColorStop(0,'#fff');g.addColorStop(.6,'#e7eae5');g.addColorStop(1,'#959f9e');c.fillStyle=g;c.beginPath();c.arc(0,0,r,0,Math.PI*2);c.fill();
    c.strokeStyle='#86949288';c.setLineDash([2,4]);c.beginPath();c.moveTo(-r,0);c.lineTo(r,0);c.moveTo(0,-r);c.lineTo(0,r);c.stroke();c.setLineDash([]);
    c.fillStyle='#d39c55';c.strokeStyle='#fff';c.lineWidth=2;c.beginPath();c.arc(this.value.x*r*.84,-this.value.y*r*.84,6,0,Math.PI*2);c.fill();c.stroke();c.restore();
    this.canvas.setAttribute('aria-valuetext',`Side spin ${Math.round(this.value.x*100)} percent, follow ${Math.round(this.value.y*100)} percent`);
  }
}
