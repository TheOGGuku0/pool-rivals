export class Multiplayer {
  constructor(onState,onEvent,onError){this.onState=onState;this.onEvent=onEvent;this.onError=onError;this.socket=null;this.connected=false;this.info=null;this.session=null;this.retry=null;this.intentional=false;this.waiter=null;}
  connect(){
    if(this.socket?.readyState===1)return Promise.resolve();if(this.waiter)return this.waiter;
    this.intentional=false;
    this.waiter=new Promise((resolve,reject)=>{
      if(location.protocol==='file:'){reject(new Error('Start the included Node server, then open http://localhost:3000.'));return;}
      const ws=new WebSocket(`${location.protocol==='https:'?'wss':'ws'}://${location.host}/pool`);this.socket=ws;
      const timeout=setTimeout(()=>ws.close(),8000);
      ws.onopen=()=>{clearTimeout(timeout);this.connected=true;this.waiter=null;if(this.session)this.send({type:'resume',...this.session});resolve();};
      ws.onmessage=e=>{let msg;try{msg=JSON.parse(e.data);}catch{return;}if(msg.type==='joined'){this.session={code:msg.code,token:msg.token};sessionStorage.setItem('eightball-room',JSON.stringify(this.session));this.seat=msg.seat;}if(msg.type==='state'){this.info=msg.room;this.onState(msg.state,msg.room);}if(msg.type==='events')for(const event of msg.events)this.onEvent(event);if(msg.type==='error'){if(msg.fatal){this.session=null;sessionStorage.removeItem('eightball-room');}this.onError(msg.message);}if(msg.type==='notice')this.onError(msg.message);};
      ws.onerror=()=>{clearTimeout(timeout);reject(new Error('Cannot reach the room server. Run node server.js and open its URL.'));};
      ws.onclose=()=>{clearTimeout(timeout);this.connected=false;this.waiter=null;reject(new Error('Room connection closed.'));if(!this.intentional&&this.session){clearTimeout(this.retry);this.retry=setTimeout(()=>this.connect().catch(()=>{}),1800);}};
    });return this.waiter;
  }
  send(message){if(this.socket?.readyState!==1)return false;this.socket.send(JSON.stringify(message));return true;}
  async create(name){await this.connect();this.send({type:'create',name});}
  async join(code,name){await this.connect();this.send({type:'join',code:code.toUpperCase().trim(),name});}
  async resume(){let saved;try{saved=JSON.parse(sessionStorage.getItem('eightball-room'));}catch{}if(saved){this.session=saved;await this.connect();return true;}return false;}
  leave(){this.intentional=true;clearTimeout(this.retry);this.send({type:'leave'});this.session=null;this.info=null;sessionStorage.removeItem('eightball-room');this.socket?.close();this.socket=null;this.connected=false;}
}
