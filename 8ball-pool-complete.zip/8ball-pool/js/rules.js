import {groupOf} from './ball.js';
export const remaining = (balls,group) => balls.filter(b=>!b.pocketed && groupOf(b.id)===group).map(b=>b.id);
export function legalTargets(state) {
  const group=state.groups[state.current];
  if(!group) {
    const solids=remaining(state.balls,'solids'),stripes=remaining(state.balls,'stripes');
    return !solids.length||!stripes.length ? [8,...solids,...stripes] : [...solids,...stripes];
  }
  const ids=remaining(state.balls,group);return ids.length?ids:[8];
}
/** Pure adjudication: only recorded shot events and the pre-shot state determine legality. */
export function evaluate(before,after,log,call) {
  const shooter=before.current,other=1-shooter,potted=log.pockets.filter(p=>p.id!==0),eight=log.pockets.find(p=>p.id===8);
  const scratch=log.pockets.some(p=>p.id===0),legal=legalTargets(before);
  let foul=scratch?'Scratch — cue ball pocketed.':log.first===null?'No object ball contacted.':null;
  if(!before.breakShot && !legal.includes(log.first)) foul ||= 'Wrong ball contacted first.';
  if(!before.breakShot && before.kitchenShot && !log.crossedHead && (before.balls.find(b=>b.id===log.first)?.x??1000)<250) foul ||= 'The cue ball must cross the head string first.';
  if(!before.breakShot && !potted.length && !log.rails.some(r=>r.afterContact)) foul ||= 'No ball reached a cushion after contact.';
  const result={current:other,groups:[...before.groups],winner:null,foul,ballInHand:foul?'any':null,breakShot:false,choice:null,message:''};
  if(before.breakShot) {
    const railCount=new Set(log.rails.filter(r=>r.id!==0).map(r=>r.id)).size;
    if(eight) {
      result.current=foul?other:shooter;
      result.choice={type:'eight-break',foul:!!foul,shooter,options:['spot','rerack']};
      result.ballInHand=foul?'kitchen':null;
      result.message=foul?'8-ball on a foul break. Spot it or re-rack.':'8-ball on the break. Spot it or break again.';
    } else if(!potted.length && railCount<4) {
      result.choice={type:'illegal-break',foul:!!foul,shooter,options:['accept','rerack','opponent-break']};
      result.ballInHand=foul?'kitchen':null;
      result.message='Illegal break — fewer than four object balls reached a cushion.';
    } else if(foul) {
      result.choice={type:'break-foul',foul:true,shooter,options:scratch?['hand']:['accept','hand']};result.ballInHand='kitchen';
      result.message=foul+' Incoming player may play from behind the head string.';
    } else {result.current=potted.length?shooter:other;result.message=potted.length?'Legal break. Table open — call your next shot.':'Table open. Next player to shoot.';}
    return result;
  }
  if(eight) {
    const valid=!foul&&legal.includes(8)&&call?.ball===8&&call.pocket===eight.pocket&&!call.safety;
    result.winner=valid?shooter:other;
    result.message=valid?'The 8-ball drops. A beautifully finished rack.':foul?'8-ball pocketed with a foul.':!legal.includes(8)?'8-ball pocketed before your group was cleared.':'8-ball pocketed in an uncalled pocket.';
    return result;
  }
  if(foul) {result.message=foul+' Ball in hand.';return result;}
  const called=call&&!call.safety&&potted.some(p=>p.id===call.ball&&p.pocket===call.pocket);
  if(called && !result.groups[shooter] && groupOf(call.ball)) {
    result.groups[shooter]=groupOf(call.ball);result.groups[other]=groupOf(call.ball)==='solids'?'stripes':'solids';
  }
  if(called && groupOf(call.ball)===result.groups[shooter]) result.current=shooter;
  result.message=call?.safety?'Safety played. Turn passes.':result.current===shooter?'Called shot made. Stay at the table.':'Turn passes. Line up your next shot.';
  return result;
}
