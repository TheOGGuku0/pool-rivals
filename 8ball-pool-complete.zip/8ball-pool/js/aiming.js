import {W,H,R,POCKETS,cloneBalls} from './ball.js';
import {step,strike,shotLog,STEP,moving} from './physics.js';
export function rayCircle(x,y,dx,dy,cx,cy,r) {
  const ox=x-cx,oy=y-cy,b=ox*dx+oy*dy,c=ox*ox+oy*oy-r*r,disc=b*b-c;
  if(disc<0)return Infinity;
  const t=-b-Math.sqrt(disc);return t>=0?t:Infinity;
}
export function predict(balls,angle) {
  const cue=balls[0],dx=Math.cos(angle),dy=Math.sin(angle);
  let distance=Infinity,target=null;
  for(const b of balls) if(b.id&&!b.pocketed) {const t=rayCircle(cue.x,cue.y,dx,dy,b.x,b.y,R*2);if(t<distance){distance=t;target=b;}}
  const tx=dx>0?(W-R-cue.x)/dx:dx<0?(R-cue.x)/dx:Infinity;
  const ty=dy>0?(H-R-cue.y)/dy:dy<0?(R-cue.y)/dy:Infinity;
  const wall=Math.min(tx,ty);
  if(wall<distance){distance=wall;target=null;}
  const x=cue.x+dx*distance,y=cue.y+dy*distance;
  let object=null,deflect=null;
  if(target) {
    const nx=(target.x-x)/(R*2),ny=(target.y-y)/(R*2),dot=dx*nx+dy*ny;
    object={x:target.x,y:target.y,dx:nx,dy:ny};deflect={x,y,dx:dx-dot*nx,dy:dy-dot*ny};
  } else deflect={x,y,dx:tx<ty?-dx:dx,dy:ty<tx?-dy:dy};
  return {x,y,dx,dy,distance,target,object,deflect};
}
export function clearPath(a,b,balls,ignore=[],radius=R*2+.5) {
  const dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy);if(len<.01)return true;
  return !balls.some(o=>!o.pocketed&&!ignore.includes(o.id)&&rayCircle(a.x,a.y,dx/len,dy/len,o.x,o.y,radius)<len);
}
export function inferredCall(balls,angle) {
  const hit=predict(balls,angle);if(!hit.target)return null;
  let pocket=0,score=-Infinity;
  for(let i=0;i<6;i++){const p=POCKETS[i],dx=p.x-hit.target.x,dy=p.y-hit.target.y,d=Math.hypot(dx,dy);const s=(dx*hit.object.dx+dy*hit.object.dy)/d;if(s>score){score=s;pocket=i;}}
  return {ball:hit.target.id,pocket,safety:false};
}
export function spinPreview(balls,angle,power,spin) {
  const copy=cloneBalls(balls),log=shotLog(),paths=new Map([[0,[]]]);strike(copy[0],angle,power,spin);
  for(let i=0;i<720;i++){step(copy,STEP,log);if(log.first!==null&&!paths.has(log.first))paths.set(log.first,[]);if(i%10===0)for(const [id,path] of paths){const b=copy.find(b=>b.id===id);if(!b.pocketed)path.push({x:b.x,y:b.y});}if(!moving(copy))break;}
  return [...paths.entries()];
}
