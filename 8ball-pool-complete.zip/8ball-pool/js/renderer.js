import {W,H,R,COLORS,POCKETS} from './ball.js';
import {predict,spinPreview} from './aiming.js';
import {drawCue} from './cue.js';
const M=65,VW=W+2*M,VH=H+2*M;
function rounded(c,x,y,w,h,r){c.beginPath();c.roundRect(x,y,w,h,r);}
function line(c,x,y,x2,y2,color,width=1,dash=[]){c.strokeStyle=color;c.lineWidth=width;c.setLineDash(dash);c.beginPath();c.moveTo(x,y);c.lineTo(x2,y2);c.stroke();c.setLineDash([]);}
export class Renderer {
  constructor(canvas){this.canvas=canvas;this.ctx=canvas.getContext('2d');this.effects=[];this.previewKey='';this.preview=[];this.lastPreview=0;this.background=this.makeTable();this.resize();new ResizeObserver(()=>this.resize()).observe(canvas);}
  resize(){const rect=this.canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);this.canvas.width=Math.max(1,Math.round(rect.width*dpr));this.canvas.height=Math.max(1,Math.round(rect.height*dpr));}
  point(e){const rect=this.canvas.getBoundingClientRect();return {x:(e.clientX-rect.left)/rect.width*VW-M,y:(e.clientY-rect.top)/rect.height*VH-M};}
  makeTable(){
    const canvas=document.createElement('canvas');canvas.width=VW*2;canvas.height=VH*2;const c=canvas.getContext('2d');c.scale(2,2);
    c.shadowColor='#0009';c.shadowBlur=22;c.shadowOffsetY=13;rounded(c,9,9,VW-18,VH-18,43);c.fillStyle='#0a1014';c.fill();c.shadowBlur=0;c.shadowOffsetY=0;
    const wood=c.createLinearGradient(0,0,0,VH);wood.addColorStop(0,'#4b3930');wood.addColorStop(.12,'#2b2522');wood.addColorStop(.8,'#241e1c');wood.addColorStop(1,'#49362c');
    rounded(c,14,14,VW-28,VH-28,37);c.fillStyle=wood;c.fill();c.strokeStyle='#9b775340';c.lineWidth=2;c.stroke();
    for(let i=0;i<16;i++){rounded(c,18+i*.9,18+i*.9,VW-36-i*1.8,VH-36-i*1.8,33-i*.7);c.strokeStyle=i%3===0?'#d7ab6510':'#0000000e';c.lineWidth=.65;c.stroke();}
    rounded(c,43,43,VW-86,VH-86,21);c.fillStyle='#082b2a';c.fill();c.strokeStyle='#947953';c.lineWidth=1.7;c.stroke();
    const felt=c.createRadialGradient(VW*.47,VH*.35,40,VW*.5,VH*.5,650);felt.addColorStop(0,'#19766e');felt.addColorStop(.55,'#12675e');felt.addColorStop(1,'#0c4b45');
    c.fillStyle=felt;c.fillRect(M,M,W,H);
    // Stable woven felt texture, rendered once, without an external asset.
    c.globalAlpha=.07;for(let y=M;y<M+H;y+=3){line(c,M,y,M+W,y,'#c1fff1',.3);}
    for(let x=M;x<M+W;x+=4){line(c,x,M,x,M+H,'#001b16',.5);}c.globalAlpha=1;
    c.save();c.translate(M,M);
    const rails=[[[30,0],[475,0],[466,-17],[43,-17]],[[525,0],[970,0],[957,-17],[534,-17]],[[30,500],[475,500],[466,517],[43,517]],[[525,500],[970,500],[957,517],[534,517]],[[0,30],[0,470],[-17,457],[-17,43]],[[1000,30],[1000,470],[1017,457],[1017,43]]];
    rails.forEach((points,i)=>{c.beginPath();points.forEach(([x,y],j)=>j?c.lineTo(x,y):c.moveTo(x,y));c.closePath();c.fillStyle=i<2?'#1d8074':i<4?'#12574e':'#17685c';c.fill();c.strokeStyle='#a0d8ac30';c.lineWidth=1;c.stroke();line(c,...points[0],...points[1],'#032c25bb',2);});
    for(let i=0;i<6;i++){const p=POCKETS[i];c.beginPath();c.arc(p.x,p.y,29,0,Math.PI*2);c.fillStyle='#9a7a51';c.fill();c.beginPath();c.arc(p.x,p.y,25,0,Math.PI*2);c.fillStyle='#060d10';c.fill();const g=c.createRadialGradient(p.x,p.y-5,4,p.x,p.y,25);g.addColorStop(0,'#010304');g.addColorStop(.8,'#04090b');g.addColorStop(1,'#243028');c.fillStyle=g;c.fill();}
    c.fillStyle='#d3c29c';
    for(const y of [-36,H+36])for(const x of [125,250,375,625,750,875]){c.beginPath();c.moveTo(x,y-3);c.lineTo(x+2,y);c.lineTo(x,y+3);c.lineTo(x-2,y);c.fill();}
    for(const x of [-36,W+36])for(const y of [125,250,375]){c.beginPath();c.moveTo(x,y-3);c.lineTo(x+2,y);c.lineTo(x,y+3);c.lineTo(x-2,y);c.fill();}
    c.fillStyle='#d9ebcf60';for(const x of [250,750]){c.beginPath();c.arc(x,250,2,0,Math.PI*2);c.fill();}
    c.textAlign='center';c.font='500 10px system-ui';c.letterSpacing='4px';c.fillStyle='#c4e5d71f';c.fillText('E I G H T  B A L L  C L U B',500,365);c.restore();
    return canvas;
  }
  event(event){if(event.type==='pocket')this.effects.push({...event,start:performance.now()});}
  draw(state,view={}) {
    const c=this.ctx,now=performance.now();c.setTransform(this.canvas.width/VW,0,0,this.canvas.height/VH,0,0);c.clearRect(0,0,VW,VH);c.drawImage(this.background,0,0,VW,VH);c.save();c.translate(M,M);
    const cue=state.balls[0];
    if(state.ballInHand==='kitchen'&&view.active){line(c,250,10,250,H-10,'#edf4da45',1,[6,8]);c.fillStyle='#ffffff05';c.fillRect(0,0,250,H);}
    if(view.call&&!view.call.safety&&view.call.pocket!==null&&view.active){const p=POCKETS[view.call.pocket];if(p){c.strokeStyle='#e7bf7f';c.lineWidth=2;c.beginPath();c.arc(p.x,p.y,31+Math.sin(now/300),0,Math.PI*2);c.stroke();c.fillStyle='#e7bf7f';c.font='bold 10px system-ui';c.textAlign='center';c.fillText(String(view.call.pocket+1),p.x+(p.x<10?21:p.x>990?-21:0),p.y<10?43:H-36);}}
    const aiming=view.active&&state.phase==='aiming'&&!state.ballInHand&&!cue.pocketed;
    if(aiming&&view.guides!==false) {
      const hit=predict(state.balls,view.angle);c.save();c.beginPath();c.rect(0,0,W,H);c.clip();
      line(c,cue.x,cue.y,hit.x,hit.y,'#effff3aa',1.2,[5,6]);c.beginPath();c.arc(hit.x,hit.y,R,0,Math.PI*2);c.strokeStyle='#eaffebaa';c.lineWidth=1;c.stroke();
      if(hit.object){const o=hit.object,d=hit.deflect;line(c,o.x,o.y,o.x+o.dx*115,o.y+o.dy*115,'#efd49cbb',1.5);line(c,d.x,d.y,d.x+d.dx*95,d.y+d.dy*95,'#ffffff77',1,[4,5]);}
      else if(hit.deflect){const d=hit.deflect;line(c,d.x,d.y,d.x+d.dx*100,d.y+d.dy*100,'#ffffff55',1,[4,6]);}
      if(view.advanced){const key=[state.shotNo,view.angle.toFixed(3),view.power.toFixed(2),view.spin.x.toFixed(2),view.spin.y.toFixed(2)].join(':');if(key!==this.previewKey&&now-this.lastPreview>160){this.preview=spinPreview(state.balls,view.angle,view.power,view.spin);this.previewKey=key;this.lastPreview=now;}for(const [id,path] of this.preview){c.beginPath();path.forEach((p,i)=>i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y));c.strokeStyle=id===0?'#a3e8dc88':'#e6c28355';c.lineWidth=1.5;c.setLineDash([2,6]);c.stroke();c.setLineDash([]);}}
      c.restore();
    }
    for(const b of state.balls)if(!b.pocketed)this.drawBall(c,b);
    for(let i=this.effects.length-1;i>=0;i--){const e=this.effects[i],t=(now-e.start)/330;if(t>1){this.effects.splice(i,1);continue;}const p=POCKETS[e.pocket];c.save();c.globalAlpha=1-t;this.drawBall(c,{id:e.id,x:e.x+(p.x-e.x)*t,y:e.y+(p.y-e.y)*t,roll:0},1-t*.85);c.restore();}
    if(aiming||view.striking)drawCue(c,cue,view.angle,view.power,view.striking||0,now);
    if(state.ballInHand&&view.active){const p=view.placement||cue;c.save();c.globalAlpha=.65;c.strokeStyle=view.placeValid?'#d9bd7e':'#e4817b';c.lineWidth=2;c.setLineDash([4,4]);c.beginPath();c.arc(p.x,p.y,R+5,0,Math.PI*2);c.stroke();c.setLineDash([]);this.drawBall(c,{id:0,x:p.x,y:p.y,roll:0});c.restore();}
    c.restore();
  }
  drawBall(c,b,scale=1) {
    const r=R*scale;if(r<=0)return;c.save();c.translate(b.x,b.y);
    c.shadowColor='#001b1dcc';c.shadowBlur=5*scale;c.shadowOffsetX=1.5*scale;c.shadowOffsetY=3*scale;
    c.beginPath();c.arc(0,0,r,0,Math.PI*2);c.fillStyle=b.id>8?'#eeeede':COLORS[b.id];c.fill();c.shadowBlur=0;c.shadowOffsetX=c.shadowOffsetY=0;
    c.save();c.beginPath();c.arc(0,0,r,0,Math.PI*2);c.clip();
    if(b.id>8){c.save();c.rotate(Math.sin((b.roll||0)*.18)*.48);c.fillStyle=COLORS[b.id-8];c.fillRect(-r,-r*.57,r*2,r*1.14);c.restore();}
    const shade=c.createRadialGradient(-r*.37,-r*.42,r*.04,0,0,r);shade.addColorStop(0,'#ffffff70');shade.addColorStop(.4,'#ffffff08');shade.addColorStop(.75,'#00000009');shade.addColorStop(1,'#00000080');c.fillStyle=shade;c.fillRect(-r,-r,r*2,r*2);
    if(b.id){c.fillStyle='#f3f0e2';c.beginPath();c.arc(0,0,r*.43,0,Math.PI*2);c.fill();c.fillStyle='#14232b';c.font=`700 ${r*.59}px Arial`;c.textAlign='center';c.textBaseline='middle';c.fillText(b.id,0,.3);}
    c.fillStyle='#ffffffad';c.beginPath();c.ellipse(-r*.35,-r*.48,r*.2,r*.1,-.4,0,Math.PI*2);c.fill();c.restore();c.restore();
  }
}
