export const W = 1000, H = 500, R = 11.5;
export const COLORS = ['#f5f4eb','#edbd35','#387ad6','#d34349','#8961bd','#ec8541','#219a7d','#913e50','#141b24'];
export const POCKETS = [
  {x:-2,y:-2,name:'Top left'}, {x:500,y:-6,name:'Top middle'}, {x:1002,y:-2,name:'Top right'},
  {x:-2,y:502,name:'Bottom left'}, {x:500,y:506,name:'Bottom middle'}, {x:1002,y:502,name:'Bottom right'}
];
export const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
export const groupOf = id => id>0 && id<8 ? 'solids' : id>8 ? 'stripes' : null;
export function ball(id,x,y) { return {id,x,y,vx:0,vy:0,wx:0,wy:0,side:0,roll:0,pocketed:false}; }
export function random(seed) { let a=seed>>>0; return ()=> { a+=0x6D2B79F5; let t=a; t=Math.imul(t^t>>>15,t|1); t^=t+Math.imul(t^t>>>7,t|61); return ((t^t>>>14)>>>0)/4294967296; }; }
export function rack(seed=1) {
  const rand=random(seed), ids=Array.from({length:15},(_,i)=>i+1).filter(n=>n!==8);
  for(let i=ids.length-1;i>0;i--) { const j=Math.floor(rand()*(i+1)); [ids[i],ids[j]]=[ids[j],ids[i]]; }
  const solid=ids.splice(ids.findIndex(n=>n<8),1)[0], stripe=ids.splice(ids.findIndex(n=>n>8),1)[0];
  const balls=[ball(0,230,250)];
  for(let row=0,k=0;row<5;row++) for(let col=0;col<=row;col++,k++) {
    const id=k===4 ? 8 : k===10 ? solid : k===14 ? stripe : ids.shift();
    balls.push(ball(id,750+row*(R*2+.04)*Math.sqrt(3)/2,250+(col-row/2)*(R*2+.04)));
  }
  return balls.sort((a,b)=>a.id-b.id);
}
export const cloneBalls = balls => balls.map(b=>({...b}));
