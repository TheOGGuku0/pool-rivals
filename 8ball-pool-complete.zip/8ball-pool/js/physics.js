import {W,H,R,POCKETS,clamp,cloneBalls} from './ball.js';
export const STEP=1/240;
const SLIDE=175, ROLL=24, RESTITUTION=.975, RAIL=.83;
export function shotLog() { return {time:0,first:null,pockets:[],rails:[],collisions:[],crossedHead:false}; }
export function strike(b,angle,power,spin={x:0,y:0}) {
  const speed=90+clamp(power,0,1)*1250, dx=Math.cos(angle),dy=Math.sin(angle);
  b.vx=dx*speed; b.vy=dy*speed;
  // wx/wy are angular surface velocities (radius times angular velocity).
  b.wx=dx*speed*spin.y*1.65; b.wy=dy*speed*spin.y*1.65; b.side=spin.x*speed*.48;
}
export function step(balls,dt=STEP,log=shotLog(),emit=null) {
  log.time+=dt;
  for(const b of balls) {
    if(b.pocketed) continue;
    b.x+=b.vx*dt; b.y+=b.vy*dt; b.roll+=Math.hypot(b.vx,b.vy)*dt/R;
    if(b.id===0 && b.x>=W/4) log.crossedHead=true;
    let pocket=-1;
    for(let i=0;i<6;i++) if(Math.hypot(b.x-POCKETS[i].x,b.y-POCKETS[i].y)<(i===1||i===4?25:25.5)) {pocket=i;break;}
    if(pocket>=0) {
      log.pockets.push({id:b.id,pocket,time:log.time});
      b.pocketed=true; b.vx=b.vy=b.wx=b.wy=b.side=0;
      emit?.({type:'pocket',id:b.id,pocket,x:b.x,y:b.y,strength:1}); continue;
    }
    const topGap=b.x<30||b.x>W-30||Math.abs(b.x-W/2)<25;
    const sideGap=b.y<30||b.y>H-30;
    if(!topGap && b.y<R && b.vy<0) bounce(b,0,1,R-b.y,log,emit);
    if(!topGap && b.y>H-R && b.vy>0) bounce(b,0,-1,b.y-(H-R),log,emit);
    if(!sideGap && b.x<R && b.vx<0) bounce(b,1,0,R-b.x,log,emit);
    if(!sideGap && b.x>W-R && b.vx>0) bounce(b,-1,0,b.x-(W-R),log,emit);
    // Rounded pocket jaws. These are physical cushions, not visual-only corners.
    for(const j of JAWS) {
      const dx=b.x-j.x,dy=b.y-j.y,d=Math.hypot(dx,dy),contact=R+3;
      if(d<contact && d>.001) bounce(b,dx/d,dy/d,contact-d,log,emit);
    }
    // Pocket throats catch balls that pass the mouth at very shallow angles.
    if(b.x<0||b.x>W||b.y<0||b.y>H) {
      let nearest=0,best=Infinity;
      POCKETS.forEach((p,i)=>{const d=Math.hypot(b.x-p.x,b.y-p.y);if(d<best){best=d;nearest=i;}});
      if(best<45) {log.pockets.push({id:b.id,pocket:nearest,time:log.time}); b.pocketed=true;b.vx=b.vy=b.wx=b.wy=b.side=0;emit?.({type:'pocket',id:b.id,pocket:nearest,x:b.x,y:b.y,strength:1});continue;}
      b.x=clamp(b.x,R,W-R);b.y=clamp(b.y,R,H-R);
    }
  }
  for(let i=0;i<balls.length;i++) {
    const a=balls[i];if(a.pocketed)continue;
    for(let j=i+1;j<balls.length;j++) {
      const b=balls[j];if(b.pocketed)continue;
      let dx=b.x-a.x,dy=b.y-a.y,d2=dx*dx+dy*dy;
      if(d2>=(2*R)**2)continue;
      const d=Math.sqrt(d2),nx=d>.0001?dx/d:1,ny=d>.0001?dy/d:0;
      const overlap=2*R-d+.00001;
      a.x-=nx*overlap*.5;a.y-=ny*overlap*.5;b.x+=nx*overlap*.5;b.y+=ny*overlap*.5;
      const rel=(a.vx-b.vx)*nx+(a.vy-b.vy)*ny;
      if(rel<=0)continue;
      const impulse=rel*(1+RESTITUTION)/2;
      a.vx-=impulse*nx;a.vy-=impulse*ny;b.vx+=impulse*nx;b.vy+=impulse*ny;
      if(log.first===null && (a.id===0||b.id===0)) log.first=a.id===0?b.id:a.id;
      if(log.collisions.length<500)log.collisions.push({a:a.id,b:b.id,time:log.time});
      emit?.({type:'collision',strength:rel/900});
    }
  }
  for(const b of balls) {
    if(b.pocketed)continue;
    const sx=b.vx-b.wx,sy=b.vy-b.wy,slip=Math.hypot(sx,sy);
    if(slip>.2) {
      // Solid sphere: I=2/5 mr², so angular surface speed changes 2.5× linear speed.
      const impulse=Math.min(SLIDE*dt,slip/3.5),nx=sx/slip,ny=sy/slip;
      b.vx-=nx*impulse;b.vy-=ny*impulse;b.wx+=nx*impulse*2.5;b.wy+=ny*impulse*2.5;
    } else {
      const v=Math.hypot(b.vx,b.vy),f=v>0?Math.max(0,v-ROLL*dt)/v:0;
      b.vx*=f;b.vy*=f;b.wx=b.vx;b.wy=b.vy;
    }
    b.side*=Math.exp(-1.05*dt);
    if(Math.hypot(b.vx,b.vy)<1 && Math.hypot(b.wx,b.wy)<1) b.vx=b.vy=b.wx=b.wy=0;
  }
}
function bounce(b,nx,ny,penetration,log,emit) {
  b.x+=nx*penetration;b.y+=ny*penetration;
  const vn=b.vx*nx+b.vy*ny;
  if(vn>=-.1)return;
  const tx=-ny,ty=nx,vt=b.vx*tx+b.vy*ty,spinImpulse=clamp((b.side-vt)*.12,-Math.abs(vn)*.24,Math.abs(vn)*.24);
  b.vx-=(1+RAIL)*vn*nx;b.vy-=(1+RAIL)*vn*ny;
  b.vx+=spinImpulse*tx;b.vy+=spinImpulse*ty;b.side-=spinImpulse*2.5;
  // Cushion friction also attenuates horizontal-axis spin.
  b.wx*=.7;b.wy*=.7;
  if(log.rails.length<500)log.rails.push({id:b.id,time:log.time,afterContact:log.first!==null});
  emit?.({type:'rail',strength:Math.abs(vn)/900});
}
export const JAWS=[{x:30,y:0},{x:475,y:0},{x:525,y:0},{x:970,y:0},{x:30,y:500},{x:475,y:500},{x:525,y:500},{x:970,y:500},{x:0,y:30},{x:0,y:470},{x:1000,y:30},{x:1000,y:470}];
export const moving = balls => balls.some(b=>!b.pocketed && (Math.hypot(b.vx,b.vy)>.01||Math.hypot(b.wx,b.wy)>.01));
export function simulate(balls,angle,power,spin={x:0,y:0},seconds=35) {
  const copy=cloneBalls(balls),log=shotLog();strike(copy.find(b=>b.id===0),angle,power,spin);
  for(let t=0;t<seconds;t+=STEP){step(copy,STEP,log);if(!moving(copy))break;}
  return {balls:copy,log};
}
