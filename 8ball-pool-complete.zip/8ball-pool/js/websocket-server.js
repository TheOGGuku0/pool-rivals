// Small RFC 6455 server transport for this dependency-free project. Handles masked
// text, fragmented messages, ping/pong, close, length limits and UTF-8 validation.
import {createHash} from 'node:crypto';
import {isUtf8} from 'node:buffer';
export function upgrade(req,socket,head,onConnection){
  const key=req.headers['sec-websocket-key'];
  if(req.headers.upgrade?.toLowerCase()!=='websocket'||req.headers['sec-websocket-version']!=='13'||typeof key!=='string'||! /^[A-Za-z0-9+/]{22}==$/.test(key)){socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');return;}
  const accept=createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
  const peer=new Peer(socket);onConnection(peer);if(head.length)peer.read(head);
}
export class Peer {
  constructor(socket){this.socket=socket;this.buffer=Buffer.alloc(0);this.fragments=[];this.fragmentSize=0;this.closed=false;this.alive=true;this.onMessage=null;this.onClose=null;socket.setNoDelay(true);socket.on('data',b=>this.read(b));socket.on('error',()=>this.close());socket.on('close',()=>{if(!this.closed){this.closed=true;this.onClose?.();}});}
  frame(op,data=Buffer.alloc(0)){
    if(this.closed||this.socket.destroyed)return;
    if(this.socket.writableLength>1000000){this.close();return;}
    const n=data.length,header=Buffer.alloc(n<126?2:4);header[0]=0x80|op;if(n<126)header[1]=n;else{header[1]=126;header.writeUInt16BE(n,2);}this.socket.write(Buffer.concat([header,data]));
  }
  send(value){const data=Buffer.from(JSON.stringify(value));if(data.length>65535)return;this.frame(1,data);}
  ping(){if(!this.alive){this.close();return;}this.alive=false;this.frame(9);}
  close(code=1000){if(this.closed)return;const b=Buffer.alloc(2);b.writeUInt16BE(code);this.frame(8,b);this.socket.end();this.socket.destroySoon();this.closed=true;this.onClose?.();}
  read(chunk){
    if(this.closed)return;this.buffer=Buffer.concat([this.buffer,chunk]);if(this.buffer.length>131072){this.close(1009);return;}
    while(this.buffer.length>=2){
      const b=this.buffer,fin=!!(b[0]&128),op=b[0]&15,masked=!!(b[1]&128);let n=b[1]&127,offset=2;
      if((b[0]&112)||!masked){this.close(1002);return;}
      if(n===126){if(b.length<4)return;n=b.readUInt16BE(2);offset=4;}else if(n===127){if(b.length<10)return;const big=b.readBigUInt64BE(2);if(big>65536n){this.close(1009);return;}n=Number(big);offset=10;}
      if(op>=8&&(!fin||n>125)){this.close(1002);return;}if(n>65536){this.close(1009);return;}
      if(b.length<offset+4+n)return;
      const mask=b.subarray(offset,offset+4),data=Buffer.from(b.subarray(offset+4,offset+4+n));for(let i=0;i<n;i++)data[i]^=mask[i%4];this.buffer=b.subarray(offset+4+n);
      if(op===8){this.close();return;}if(op===9){this.frame(10,data);continue;}if(op===10){this.alive=true;continue;}
      if(op!==0&&op!==1){this.close(1003);return;}
      if(op===0&&!this.fragments.length||op===1&&this.fragments.length){this.close(1002);return;}
      this.fragments.push(data);this.fragmentSize+=n;if(this.fragmentSize>16384){this.close(1009);return;}
      if(fin){const message=Buffer.concat(this.fragments);this.fragments=[];this.fragmentSize=0;if(!isUtf8(message)){this.close(1007);return;}try{const value=JSON.parse(message.toString());if(!value||typeof value!=='object'||Array.isArray(value))throw Error();this.onMessage?.(value);}catch{this.send({type:'error',message:'Invalid room message.'});}}
    }
  }
}
