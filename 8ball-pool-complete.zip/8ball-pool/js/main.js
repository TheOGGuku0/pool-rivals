import {Game} from './game.js';
import {Renderer} from './renderer.js';
import {STEP} from './physics.js';
import {SpinControl} from './spin.js';
import {AudioEngine} from './audio.js';
import {UI,$,toast,safeName} from './ui.js';
import {Input} from './input.js';
import {chooseShot,placeForBot} from './ai.js';
import {inferredCall} from './aiming.js';
import {legalTargets} from './rules.js';
import {Multiplayer} from './multiplayer.js';
class App {
  constructor(){
    this.game=new Game();this.renderer=new Renderer($('table'));this.audio=new AudioEngine();this.ui=new UI(this);this.mode='bot';this.difficulty='medium';this.names=['You','The House'];this.active=false;this.angle=0;this.power=.55;this.call={ball:null,pocket:null,safety:false};this.placement=null;this.thinking=false;this.botTimer=null;this.strikeStart=0;this.pendingShot=null;this.lastShotNo=0;this.lastTurn=0;this.paused=false;
    this.preferences={guides:true,advanced:false,sound:true,volume:.45};try{Object.assign(this.preferences,JSON.parse(localStorage.getItem('eightball-settings'))||{});}catch{}
    $('setting-guides').checked=this.preferences.guides;$('setting-advanced').checked=this.preferences.advanced;$('setting-sound').checked=this.preferences.sound;$('setting-volume').value=this.preferences.volume*100;this.audio.enabled=this.preferences.sound;this.audio.volume=this.preferences.volume;
    this.spin=new SpinControl($('spin-canvas'),v=>{$('spin-label').textContent=Math.hypot(v.x,v.y)<.05?'Center ball':[v.y>.15?'Follow':v.y<-.15?'Draw':'',v.x>.15?'Right':v.x<-.15?'Left':''].filter(Boolean).join(' + ');});
    this.net=new Multiplayer((state,room)=>this.networkState(state,room),e=>this.event(e),m=>{toast(m);$('connection-message').textContent=m;});
    this.game.onEvent=e=>this.event(e);this.input=new Input(this);this.ui.showMenu();this.bind();this.ui.power();
    this.last=performance.now();this.accumulator=0;requestAnimationFrame(t=>this.frame(t));
    if(new URLSearchParams(location.search).has('room')){$('room-code').value=new URLSearchParams(location.search).get('room').slice(0,6);this.openMode('player');this.onlineTab();}
    this.net.resume().catch(()=>{});
  }
  bind(){
    document.addEventListener('pointerdown',()=>this.audio.unlock(),{once:true});
    $('bot-button').onclick=()=>this.openMode('bot');$('player-button').onclick=()=>this.openMode('player');
    document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>b.closest('dialog').close());
    document.querySelectorAll('dialog').forEach(d=>{d.addEventListener('close',()=>{this.paused=false;this.last=performance.now();});d.addEventListener('click',e=>{if(e.target===d&&d.id!=='winner-dialog'){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}});});
    document.querySelectorAll('[data-difficulty]').forEach(b=>b.onclick=()=>{this.difficulty=b.dataset.difficulty;document.querySelectorAll('[data-difficulty]').forEach(el=>el.classList.toggle('selected',el===b));});
    $('start-bot').onclick=()=>this.start('bot',[safeName($('bot-name').value,'You'),'The House']);
    $('start-local').onclick=()=>this.start('local',[safeName($('local-name-0').value,'Player 1'),safeName($('local-name-1').value,'Player 2')]);
    $('local-tab').onclick=()=>{ $('local-options').hidden=false;$('online-options').hidden=true;$('local-tab').classList.add('selected');$('online-tab').classList.remove('selected');};$('online-tab').onclick=()=>this.onlineTab();
    $('create-room').onclick=()=>this.connectRoom(false);$('join-room').onclick=()=>this.connectRoom(true);
    $('call-ball').onchange=()=>{this.call.ball=$('call-ball').value===''?null:Number($('call-ball').value);};$('call-pocket').onchange=()=>{this.call.pocket=$('call-pocket').value===''?null:Number($('call-pocket').value);};$('safety').onchange=()=>this.call.safety=$('safety').checked;
    $('auto-call').onclick=()=>{const call=inferredCall(this.game.state.balls,this.angle);if(call&&legalTargets(this.game.state).includes(call.ball)){this.call=call;this.ui.callChanged();toast('Suggested call selected. Check the highlighted pocket.');}else toast('Aim at one of your legal target balls first.');};
    $('spin-reset').onclick=()=>this.spin.reset();$('place-default').onclick=()=>{const p=this.placement||this.game.state.balls[0];if(!this.place(p.x,p.y))toast('Choose a clear position on the table.');};
    $('settings-button').onclick=() =>this.settings();$('pause-button').onclick=()=>this.settings();
    $('help-button').onclick=()=>{this.paused=this.mode!=='online';$('help-dialog').showModal();};
    $('sound-button').onclick=()=>{this.preferences.sound=!this.audio.enabled;$('setting-sound').checked=this.preferences.sound;this.saveSettings();};
    for(const id of ['setting-guides','setting-advanced','setting-sound','setting-volume'])$(id).oninput=()=>this.saveSettings();
    $('restart-button').onclick=()=>{if(this.mode==='online'){this.rematch();return;}this.confirm('Start a fresh rack?','The current rack will end.','Start fresh',()=>this.restart());};
    $('menu-button').onclick=()=>this.leavePrompt();$('brand').onclick=e=>{e.preventDefault();if(this.active)this.leavePrompt();};
    $('winner-menu').onclick=()=>this.menu();$('rematch-button').onclick=()=>this.rematch();
  }
  openMode(mode){$('mode-title').textContent=mode==='bot'?'Choose your opponent.':'Better with company.';$('bot-options').hidden=mode!=='bot';$('player-options').hidden=mode==='bot';$('mode-dialog').showModal();}
  onlineTab(){$('local-options').hidden=true;$('online-options').hidden=false;$('online-tab').classList.add('selected');$('local-tab').classList.remove('selected');}
  async connectRoom(join){const button=$(join?'join-room':'create-room');button.disabled=true;$('connection-message').textContent='Connecting to the table…';try{if(this.net.session)this.net.leave();const name=safeName($('online-name').value,'Player');if(join)await this.net.join($('room-code').value,name);else await this.net.create(name);}catch(e){$('connection-message').textContent=e.message;}finally{button.disabled=false;}}
  start(mode,names){this.cancelBot();this.net.leave();this.mode=mode;this.names=names;this.active=true;this.game=new Game();this.game.onEvent=e=>this.event(e);this.resetControls();this.closeDialogs();this.ui.showGame();this.ui.winnerKey='';this.ui.render();this.renderer.resize();}
  resetControls(){this.angle=0;this.power=.55;this.call={ball:null,pocket:null,safety:false};this.placement=null;this.strikeStart=0;this.pendingShot=null;this.spin.reset();this.ui.power();this.ui.callChanged();this.ui.lastKey='';this.ui.callKey='';this.lastShotNo=this.game.state.shotNo;this.lastTurn=this.game.state.current;}
  closeDialogs(){document.querySelectorAll('dialog[open]').forEach(d=>d.close());this.paused=false;}
  settings(){this.paused=this.mode!=='online';$('pause-note').textContent=this.mode==='online'?'Online play continues while Settings is open.':'Your local game is paused while this panel is open.';$('settings-dialog').showModal();}
  saveSettings(){this.preferences={guides:$('setting-guides').checked,advanced:$('setting-advanced').checked,sound:$('setting-sound').checked,volume:Number($('setting-volume').value)/100};this.audio.enabled=this.preferences.sound;this.audio.volume=this.preferences.volume;try{localStorage.setItem('eightball-settings',JSON.stringify(this.preferences));}catch{}$('sound-button').textContent=this.audio.enabled?'♫':'♪';$('sound-button').setAttribute('aria-label',this.audio.enabled?'Mute sound':'Enable sound');$('sound-button').title=this.audio.enabled?'Sound on':'Sound off';}
  confirm(title,message,label,action){this.paused=this.mode!=='online';$('confirm-title').textContent=title;$('confirm-text').textContent=message;$('confirm-yes').textContent=label;$('confirm-yes').onclick=()=>{$('confirm-dialog').close();action();};$('confirm-dialog').showModal();}
  leavePrompt(){this.confirm('Leave the table?',this.mode==='online'?'Leaving concedes this rack to your opponent.':'Your current rack will end.','Leave table',()=>this.menu());}
  menu(){this.cancelBot();this.net.leave();this.closeDialogs();this.active=false;this.game=new Game();this.resetControls();this.ui.showMenu();this.renderer.resize();history.replaceState(null,'',location.pathname);}
  restart(){this.cancelBot();const next=1-this.game.state.starter;this.game.reset(Date.now(),next);this.resetControls();this.closeDialogs();this.ui.winnerKey='';}
  rematch(){if(this.mode==='online'){this.net.send({type:'rematch'});toast('Rematch requested. Both players must agree.');$('rematch-button').textContent='Waiting for opponent…';}else this.restart();}
  canControl(){if(!this.active||this.strikeStart)return false;const s=this.game.state;if(this.mode==='online')return this.net.connected&&this.net.info?.ready&&this.net.seat===s.current;if(this.paused)return false;return this.mode==='local'||s.current===0;}
  validCall(){return this.call.safety||(legalTargets(this.game.state).includes(this.call.ball)&&Number.isInteger(this.call.pocket));}
  place(x,y){if(!this.canControl()||!this.game.canPlace(x,y))return false;if(this.mode==='online')return this.net.send({type:'place',x,y});return this.game.place(x,y);}
  choose(option){if(!this.canControl())return;if(this.mode==='online')this.net.send({type:'choice',option});else this.game.choose(option);}
  shoot(){const s=this.game.state;if(!this.canControl()||s.phase!=='aiming'||s.ballInHand)return;if(!s.breakShot&&!this.validCall()){toast('Call a ball and pocket, or choose a safety.');return;}this.audio.unlock();this.pendingShot={angle:this.angle,power:this.power,spin:{...this.spin.value},call:{...this.call}};this.strikeStart=performance.now();}
  event(event){this.renderer.event(event);this.audio.play(event);}
  networkState(state,room){const newRack=this.game.state.seed!==state.seed,first=this.mode!=='online'||!this.active;this.cancelBot();this.mode='online';this.active=true;this.names=[room.players[0]?.name||'Player 1',room.players[1]?.name||'Waiting for a friend'];this.game.load(state);if(first||newRack){this.resetControls();this.ui.winnerKey='';this.closeDialogs();this.ui.showGame();this.renderer.resize();}if(state.phase==='over'&&state.winner!==null&&room.rematchVotes?.includes(this.net.seat))$('rematch-button').textContent='Waiting for opponent…';}
  copyRoom(){const url=new URL(location.href);url.searchParams.set('room',this.net.info.code);navigator.clipboard?.writeText(url.href).then(()=>toast('Invite link copied.')).catch(()=>toast(`Room code: ${this.net.info.code}`));}
  cancelBot(){clearTimeout(this.botTimer);this.botTimer=null;this.thinking=false;}
  maybeBot(){const s=this.game.state;if(!this.active||this.mode!=='bot'||s.current!==1||s.phase==='moving'||s.phase==='over'||this.botTimer||this.paused)return;this.thinking=true;const seed=s.seed;this.botTimer=setTimeout(()=>{this.botTimer=null;if(this.paused){this.thinking=false;return;}if(!this.active||this.mode!=='bot'||this.game.state.seed!==seed)return;const state=this.game.state;if(state.phase==='choice')this.game.choose(state.choice.options.includes('spot')?'spot':state.choice.options.includes('hand')?'hand':'accept');if(this.game.state.ballInHand)placeForBot(this.game);const shot=chooseShot(this.game.state,this.difficulty);this.thinking=false;this.game.shoot(shot);},900+Math.random()*600);}
  frame(now){
    const elapsed=Math.min((now-this.last)/1000,.1);this.last=now;
    if(this.strikeStart&&(!this.paused||this.mode==='online')&&now-this.strikeStart>=120){const action=this.pendingShot;this.strikeStart=0;this.pendingShot=null;if(this.mode==='online')this.net.send({type:'shot',action});else this.game.shoot(action);}
    if(this.active&&this.mode!=='online'&&!this.paused){this.accumulator+=elapsed;while(this.accumulator>=STEP){this.game.tick(STEP);this.accumulator-=STEP;}}else this.accumulator=0;
    const s=this.game.state;if(s.phase==='aiming'&&(this.lastShotNo!==s.shotNo||this.lastTurn!==s.current)){this.lastShotNo=s.shotNo;this.lastTurn=s.current;this.call={ball:null,pocket:null,safety:false};this.spin.reset();this.placement=null;this.ui.callChanged();}
    this.maybeBot();this.ui.render();this.renderer.draw(s,{active:this.canControl(),angle:this.angle,power:this.power,spin:this.spin.value,call:this.call,guides:this.preferences.guides,advanced:this.preferences.advanced,striking:this.strikeStart?Math.min(1,(now-this.strikeStart)/120):0,placement:this.placement,placeValid:this.placement?this.game.canPlace(this.placement.x,this.placement.y):true});
    requestAnimationFrame(t=>this.frame(t));
  }
}
const app=new App();
// Deliberate read-only diagnostics: useful for checking deployments without changing play.
globalThis.poolDiagnostics=()=>({mode:app.mode,phase:app.game.state.phase,shotNo:app.game.state.shotNo,current:app.game.state.current,ballCount:app.game.state.balls.filter(b=>!b.pocketed).length,connected:app.net.connected});
