import {W,H,R,POCKETS,clamp,random} from './ball.js';
import {legalTargets} from './rules.js';
import {clearPath} from './aiming.js';
import {simulate} from './physics.js';
export function placeForBot(game) {
  const s=game.state,targets=legalTargets(s).map(id=>s.balls.find(b=>b.id===id));
  const candidates=[];
  for(const b of targets) for(const p of POCKETS) {
    const dx=b.x-p.x,dy=b.y-p.y,len=Math.hypot(dx,dy);
    for(const distance of [90,150,230])candidates.push({x:b.x+dx/len*distance,y:b.y+dy/len*distance});
  }
  candidates.push({x:230,y:250});
  for(let x=R+15;x<W-R;x+=40)for(let y=R+15;y<H-R;y+=40)candidates.push({x,y});
  for(const p of candidates)if(game.canPlace(p.x,p.y)&&targets.some(b=>clearPath(p,b,s.balls,[0,b.id])))return game.place(p.x,p.y);
  for(const p of candidates)if(game.canPlace(p.x,p.y))return game.place(p.x,p.y);
  return false;
}
export function chooseShot(state,difficulty='medium') {
  const rng=random(state.seed+state.shotNo*7919),cue=state.balls[0];
  if(state.breakShot)return {angle:Math.atan2(250-cue.y,750-cue.x)+(rng()-.5)*.005,power:.94,spin:{x:0,y:.12},call:null};
  const legal=legalTargets(state),candidates=[];
  for(const id of legal) {
    const target=state.balls.find(b=>b.id===id);
    for(let i=0;i<6;i++) {
      const pocket=POCKETS[i],dx=pocket.x-target.x,dy=pocket.y-target.y,len=Math.hypot(dx,dy),nx=dx/len,ny=dy/len;
      const ghost={x:target.x-nx*R*2,y:target.y-ny*R*2};
      if(ghost.x<R||ghost.x>W-R||ghost.y<R||ghost.y>H-R)continue;
      const cx=ghost.x-cue.x,cy=ghost.y-cue.y,dist=Math.hypot(cx,cy),cut=(cx*nx+cy*ny)/dist;
      if(cut<.24||!clearPath(cue,ghost,state.balls,[0,id])||!clearPath(target,pocket,state.balls,[0,id],R*2+1))continue;
      const speed=Math.sqrt(2*24*(dist+len/(cut*cut)))*1.48+85;
      const power=clamp((speed-90)/1250,.16,.82);
      candidates.push({angle:Math.atan2(cy,cx),power,spin:{x:0,y:difficulty==='easy'?0:.12},call:{ball:id,pocket:i,safety:false},score:cut*600-dist*.15-len*.2});
    }
  }
  candidates.sort((a,b)=>b.score-a.score);
  const count=difficulty==='hard'?9:difficulty==='medium'?4:1;
  for(const c of candidates.slice(0,count)) {
    const result=simulate(state.balls,c.angle,c.power,c.spin);
    const pot=result.log.pockets.some(p=>p.id===c.call.ball&&p.pocket===c.call.pocket);
    const scratch=result.log.pockets.some(p=>p.id===0),badEight=c.call.ball!==8&&result.log.pockets.some(p=>p.id===8);
    const finalCue=result.balls[0],next=legal.filter(id=>id!==c.call.ball).map(id=>result.balls.find(b=>b.id===id)).filter(b=>!b.pocketed);
    const options=next.filter(b=>clearPath(finalCue,b,result.balls,[0,b.id])).length;
    c.score+=(pot?2000:0)-(scratch?3000:0)-(badEight?9000:0)+options*35-Math.hypot(finalCue.x-W/2,finalCue.y-H/2)*.05;
    c.simulated=true;
  }
  const tested=candidates.filter(c=>c.simulated).sort((a,b)=>b.score-a.score);
  let shot=tested[0];
  if(!shot||shot.score<200) {
    // Safety candidates include direct contacts and one-cushion kicks. Rank legal
    // simulations by how few clear object-ball paths the opponent is left with.
    const safeties=[];
    for(const id of legal) {
      const target=state.balls.find(b=>b.id===id),points=[target,{x:-target.x,y:target.y},{x:2*W-target.x,y:target.y},{x:target.x,y:-target.y},{x:target.x,y:2*H-target.y}];
      for(const p of points) {
        const angle=Math.atan2(p.y-cue.y,p.x-cue.x),power=p===target?.34:.5;
        const result=simulate(state.balls,angle,power,{x:0,y:0});
        const foul=!legal.includes(result.log.first)||result.log.pockets.some(p=>p.id===0||p.id===8)||(!result.log.pockets.length&&!result.log.rails.some(r=>r.afterContact));
        const q=result.balls[0];let exposed=0;for(const b of result.balls)if(b.id&&b.id!==8&&!b.pocketed&&clearPath(q,b,result.balls,[0,b.id]))exposed++;
        safeties.push({angle,power,spin:{x:0,y:0},call:{safety:true},score:(foul?-10000:0)-exposed*20});
      }
      if(safeties.some(s=>s.score>-200))break;
    }
    safeties.sort((a,b)=>b.score-a.score);if(safeties[0]&&(!shot||safeties[0].score>shot.score-700))shot=safeties[0];
  }
  shot ||= {angle:0,power:.4,spin:{x:0,y:0},call:{safety:true}};
  const error=difficulty==='easy'?.032:difficulty==='medium'?.008:.0012;
  return {...shot,angle:shot.angle+(rng()-.5)*2*error,power:clamp(shot.power*(1+(rng()-.5)*(difficulty==='easy'?.25:.06)),.02,1)};
}
