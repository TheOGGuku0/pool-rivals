export class AudioEngine {
  constructor(){this.enabled=true;this.volume=.45;this.last=0;this.ctx=null;}
  unlock(){if(!this.ctx){const AC=globalThis.AudioContext||globalThis.webkitAudioContext;if(AC)this.ctx=new AC();}this.ctx?.resume().catch(()=>{});}
  play(event){
    if(!this.enabled||!this.ctx)return;
    const now=this.ctx.currentTime,type=event.type;
    if(type==='collision'&&now-this.last<.023)return;if(type==='collision')this.last=now;
    const strength=Math.max(.03,Math.min(1,event.strength||.3)),volume=this.volume*strength;
    if(['collision','rail','strike','pocket','click'].includes(type)) {
      const osc=this.ctx.createOscillator(),gain=this.ctx.createGain();osc.connect(gain);gain.connect(this.ctx.destination);
      osc.type=type==='pocket'?'sine':'triangle';const f={collision:1100,rail:210,strike:650,pocket:130,click:750}[type];
      osc.frequency.setValueAtTime(f,now);osc.frequency.exponentialRampToValueAtTime(f*.3,now+.09);
      gain.gain.setValueAtTime(Math.max(.0001,volume*.3),now);gain.gain.exponentialRampToValueAtTime(.0001,now+.12);osc.start(now);osc.stop(now+.13);
    } else if(type==='win'||type==='foul') {
      (type==='win'?[392,494,587,784]:[220,164]).forEach((f,i)=>{const o=this.ctx.createOscillator(),g=this.ctx.createGain(),t=now+i*.13;o.connect(g);g.connect(this.ctx.destination);o.frequency.value=f;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(volume*.15,t+.015);g.gain.exponentialRampToValueAtTime(.0001,t+.28);o.start(t);o.stop(t+.3);});
    }
  }
}
