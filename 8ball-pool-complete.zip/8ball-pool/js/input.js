import {POCKETS,R,clamp} from './ball.js';
import {legalTargets} from './rules.js';
import {$,toast} from './ui.js';
export class Input {
  constructor(app){this.app=app;this.drag=null;this.aimDrag=null;this.powerPointer=null;
    const canvas=$('table');
    canvas.addEventListener('pointermove',e=>{const p=app.renderer.point(e);if(app.game.state.ballInHand){app.placement=p;return;}if(e.pointerType==='mouse'||this.aimDrag===e.pointerId)this.aim(p);});
    canvas.addEventListener('pointerdown',e=>{app.audio.unlock();this.aimDrag=e.pointerId;canvas.setPointerCapture(e.pointerId);this.drag={x:e.clientX,y:e.clientY};if(app.game.state.ballInHand)return;this.aim(app.renderer.point(e));});
    canvas.addEventListener('pointerup',e=>{const p=app.renderer.point(e),small=this.drag&&Math.hypot(e.clientX-this.drag.x,e.clientY-this.drag.y)<8;this.aimDrag=null;this.drag=null;if(!app.canControl()||app.game.state.phase!=='aiming')return;if(app.game.state.ballInHand){if(!app.place(p.x,p.y))toast('Place the cue ball on a clear spot inside the permitted area.');return;}if(small&&!app.game.state.breakShot){const pocket=POCKETS.findIndex(o=>Math.hypot(o.x-p.x,o.y-p.y)<35);if(pocket>=0){app.call.pocket=pocket;app.call.safety=false;app.ui.callChanged();return;}const b=app.game.state.balls.find(b=>!b.pocketed&&b.id&&Math.hypot(b.x-p.x,b.y-p.y)<R*2);if(b&&legalTargets(app.game.state).includes(b.id)){app.call.ball=b.id;app.call.safety=false;app.ui.callChanged();}}});
    canvas.addEventListener('pointercancel',()=>{this.aimDrag=null;this.drag=null;});
    canvas.addEventListener('wheel',e=>{if(app.active&&app.canControl()){e.preventDefault();app.angle+=Math.sign(e.deltaY)*(e.shiftKey?.0005:.003);}}, {passive:false});
    const power=$('power-track');
    const update=e=>{const r=power.getBoundingClientRect();app.power=clamp((e.clientX-r.left)/r.width,.01,1);app.ui.power();};
    power.addEventListener('pointerdown',e=>{if(power.getAttribute('aria-disabled')==='true')return;app.audio.unlock();this.powerPointer=e.pointerId;power.setPointerCapture(e.pointerId);update(e);});
    power.addEventListener('pointermove',e=>{if(this.powerPointer===e.pointerId)update(e);});
    power.addEventListener('pointerup',e=>{if(this.powerPointer!==e.pointerId)return;this.powerPointer=null;app.shoot();});
    power.addEventListener('pointercancel',()=>this.powerPointer=null);
    power.addEventListener('keydown',e=>{if(power.getAttribute('aria-disabled')==='true')return;if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Enter',' '].includes(e.key)){e.preventDefault();e.stopPropagation();if(e.key==='Enter'||e.key===' '){if(!e.repeat)app.shoot();}else{app.power=clamp(app.power+(['ArrowRight','ArrowUp'].includes(e.key)?.02:-.02),.01,1);app.ui.power();}}});
    window.addEventListener('keydown',e=>{if(e.key==='Escape'){if(document.querySelector('dialog[open]'))return;if(app.active){e.preventDefault();app.settings();}return;}if(document.querySelector('dialog[open]')||['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName)||e.target===$('spin-canvas'))return;if(app.active&&app.canControl()&&['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();app.angle+=(e.key==='ArrowLeft'?-1:1)*(e.shiftKey?.0005:.003);}});
    $('aim-left').onclick=()=>{if(app.canControl())app.angle-=.002;};$('aim-right').onclick=()=>{if(app.canControl())app.angle+=.002;};
  }
  aim(p){const a=this.app,s=a.game.state;if(a.canControl()&&s.phase==='aiming'&&!s.ballInHand&&!a.strikeStart)a.angle=Math.atan2(p.y-s.balls[0].y,p.x-s.balls[0].x);}
}
