import {COLORS,groupOf,POCKETS} from './ball.js';
import {legalTargets,remaining} from './rules.js';
export const $=id=>document.getElementById(id);
export function toast(message){$('toast').textContent=message;$('toast').classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').classList.remove('show'),3500);}
export function safeName(value,fallback){return String(value||'').trim().slice(0,24)||fallback;}
export class UI {
  constructor(app){this.app=app;this.lastKey='';this.callKey='';this.winnerKey='';}
  showGame(){ $('menu').hidden=true;$('game-screen').hidden=false;$('game-table-slot').append($('table-wrap')); }
  showMenu(){ $('menu').hidden=false;$('game-screen').hidden=true;$('menu-table-slot').append($('table-wrap'));this.lastKey=''; }
  render(){
    const a=this.app,s=a.game.state,online=a.mode==='online',ready=a.canControl();
    const network=online?a.net.info:null;
    const key=JSON.stringify([s.current,s.groups,s.phase,s.balls.filter(b=>b.pocketed).map(b=>b.id),s.message,s.shotNo,s.ballInHand,a.thinking,a.names,a.mode,a.net.info,a.active]);
    if(key!==this.lastKey){
      this.lastKey=key;
      for(let p=0;p<2;p++){
        $('name-'+p).textContent=a.names[p];$('player-'+p).classList.toggle('active',s.current===p&&s.phase!=='over');$('turn-'+p).style.visibility=s.current===p&&s.phase!=='over'?'visible':'hidden';
        const group=s.groups[p];$('group-'+p).textContent=group?`${group==='solids'?'Solids':'Stripes'} · ${remaining(s.balls,group).length} remaining`:'Open table';
        const tray=$('balls-'+p);tray.replaceChildren();
        if(!group){const placeholder=document.createElement('span');placeholder.className='empty-tray';tray.append(placeholder);}else for(const b of s.balls.filter(b=>groupOf(b.id)===group)){const el=document.createElement('span');el.className='mini-ball'+(b.id>8?' stripe':'')+(b.pocketed?' potted':'');el.style.setProperty('--ball',COLORS[b.id>8?b.id-8:b.id]);el.dataset.number=b.id;el.title=`Ball ${b.id}${b.pocketed?' pocketed':''}`;tray.append(el);}
      }
      let message=a.thinking?`${a.names[1]} is studying the table…`:s.message;
      if(online&&network&&!network.ready)message=network.players.length<2?`Room ${network.code} · Waiting for a friend. Share this code or the room link.`:'Opponent disconnected. Table paused for reconnection (60 seconds).';
      if(online&&!a.net.connected)message='Connection lost. Reconnecting to your table…';
      $('status').textContent=message;$('status').parentElement.classList.toggle('foul',!!s.foul);$('shot-count').textContent=`SHOT ${String(s.shotNo+1).padStart(2,'0')}`;
      $('mode-label').textContent=a.mode==='bot'?`PLAYER VS BOT · ${a.difficulty.toUpperCase()}`:a.mode==='local'?'LOCAL MATCH · PASS & PLAY':`PRIVATE ROOM · ${network?.code||'CONNECTING'}`;
      $('turn-tip').textContent=s.ballInHand?'Click or tap a clear spot to place the cue ball.':s.phase==='moving'?'A moment of momentum.':online&&!ready?'Your opponent is at the table.':`${a.names[s.current]}'s turn · Aim, call, and release the power meter.`;
      $('place-default').hidden=!ready||!s.ballInHand;$('place-default').textContent='Place cue ball here ✓';
      $('restart-button').textContent=online?'↻ Request rematch':'↻ New rack';
      const bar=$('choice-bar');bar.replaceChildren();bar.hidden=true;
      if(s.phase==='choice'){
        bar.hidden=false;const label=document.createElement('span');label.textContent=ready?'Your break choice:':`${a.names[s.current]} is choosing…`;bar.append(label);
        if(ready)for(const option of s.choice.options){const b=document.createElement('button');b.textContent={spot:'Spot the 8-ball',rerack:'Re-rack & break','opponent-break':'Let opponent re-break',accept:'Accept the table',hand:'Take ball in hand'}[option];b.onclick=()=>a.choose(option);bar.append(b);}
      } else if(online&&network?.code&&network.players.length<2){bar.hidden=false;const label=document.createElement('span');label.textContent=`Your private room: ${network.code}`;const copy=document.createElement('button');copy.textContent='Copy invite link';copy.onclick=()=>a.copyRoom();bar.append(label,copy);}
      if(s.phase==='over'&&a.active&&this.winnerKey!==s.seed+':'+s.winner){this.winnerKey=s.seed+':'+s.winner;$('winner-title').textContent=`${a.names[s.winner]} wins.`;$('winner-detail').textContent=s.message;$('win-stats').textContent=`${s.shotNo} SHOTS · ${a.mode==='bot'?'PLAYER VS BOT':a.mode==='local'?'LOCAL MATCH':'PRIVATE MATCH'}`;$('rematch-button').textContent=online?'Request rematch ↗':'Play another rack ↗';$('winner-dialog').showModal();}
    }
    const ids=legalTargets(s),callKey=ids.join(',');
    if(callKey!==this.callKey){this.callKey=callKey;const select=$('call-ball'),value=select.value;select.replaceChildren(new Option('Select ball',''));for(const id of ids)select.add(new Option(`Ball ${id}`,id));if(ids.includes(Number(value)))select.value=value;else a.call.ball=null;}
    const canAim=ready&&s.phase==='aiming'&&!s.ballInHand;
    $('power-track').setAttribute('aria-disabled',String(!canAim));
    const callEnabled=canAim&&!s.breakShot;
    for(const id of ['call-ball','call-pocket','safety','auto-call'])$(id).disabled=!callEnabled;
    $('call-ball').disabled||=a.call.safety;$('call-pocket').disabled||=a.call.safety;
    $('power-hint').textContent=!ready?'Waiting for your turn':s.ballInHand?'Place the cue ball first':s.phase==='moving'?'Shot in progress':!s.breakShot&&!a.validCall()?'Call a ball & pocket first':'Drag and release to shoot';
  }
  callChanged(){const a=this.app;$('call-ball').value=a.call.ball??'';$('call-pocket').value=a.call.pocket??'';$('safety').checked=a.call.safety;}
  power(){const pct=Math.round(this.app.power*100);$('power-value').textContent=pct+'%';$('power-fill').style.width=pct+'%';$('power-knob').style.left=pct+'%';$('power-track').setAttribute('aria-valuenow',pct);}
}
