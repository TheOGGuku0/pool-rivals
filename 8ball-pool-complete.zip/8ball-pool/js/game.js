import {W,H,R,POCKETS,rack,cloneBalls,ball} from './ball.js';
import {step,strike,moving,shotLog,STEP} from './physics.js';
import {evaluate,legalTargets} from './rules.js';
export class Game {
  constructor(seed=Date.now(),starter=0) {this.reset(seed,starter);this.onEvent=null;}
  reset(seed=Date.now(),starter=0) {
    this.state={balls:rack(seed),current:starter,starter,groups:[null,null],phase:'aiming',breakShot:true,ballInHand:'kitchen',kitchenShot:true,winner:null,message:'Place the cue ball behind the head string, then break.',foul:null,choice:null,shotNo:0,seed};
    this.log=null;this.before=null;this.call=null;
  }
  canPlace(x,y) {
    if(!Number.isFinite(x)||!Number.isFinite(y)||x<R||x>W-R||y<R||y>H-R)return false;
    if(this.state.ballInHand==='kitchen'&&x>=W/4-R)return false;
    if(POCKETS.some(p=>Math.hypot(x-p.x,y-p.y)<33))return false;
    return !this.state.balls.some(b=>b.id!==0&&!b.pocketed&&Math.hypot(x-b.x,y-b.y)<R*2+.2);
  }
  place(x,y,actor=this.state.current) {
    const s=this.state;if(actor!==s.current||s.phase!=='aiming'||!s.ballInHand||!this.canPlace(x,y))return false;
    s.kitchenShot=s.ballInHand==='kitchen';Object.assign(s.balls[0],ball(0,x,y));s.ballInHand=null;
    s.message=s.breakShot?'Ready for the break. Pull the power meter and release.':'Cue ball placed. Call your shot and aim.';return true;
  }
  shoot(action,actor=this.state.current) {
    const s=this.state;if(actor!==s.current||s.phase!=='aiming'||s.ballInHand)return false;
    const {angle,power,spin={x:0,y:0},call=null}=action||{};
    if(![angle,power,spin?.x,spin?.y].every(Number.isFinite)||power<.01||power>1||Math.hypot(spin.x,spin.y)>1.001)return false;
    if(!s.breakShot && (!call || (!call.safety && (!legalTargets(s).includes(call.ball)||!Number.isInteger(call.pocket)||call.pocket<0||call.pocket>5))))return false;
    this.before={...s,balls:cloneBalls(s.balls),groups:[...s.groups]};this.call=call;this.log=shotLog();
    strike(s.balls[0],angle,power,spin);s.phase='moving';s.shotNo++;s.foul=null;s.message='Balls in motion…';this.onEvent?.({type:'strike',strength:power});return true;
  }
  tick(dt=STEP) {
    const s=this.state;if(s.phase!=='moving')return false;
    step(s.balls,dt,this.log,this.onEvent);
    if(!moving(s.balls)) {
      Object.assign(s,evaluate(this.before,s.balls,this.log,this.call));s.kitchenShot=false;
      s.phase=s.winner!==null?'over':s.choice?'choice':'aiming';
      this.onEvent?.({type:s.winner!==null?'win':s.foul?'foul':'turn',strength:1});return true;
    }
    return false;
  }
  choose(option,actor=this.state.current) {
    const s=this.state,c=s.choice;if(s.phase!=='choice'||actor!==s.current||!c.options.includes(option))return false;
    if(option==='rerack'||option==='opponent-break') {this.reset(s.seed+1,option==='opponent-break'?c.shooter:s.current);return true;}
    if(c.type==='eight-break')this.spotEight();
    s.ballInHand=option==='hand'||(c.foul&&c.type==='eight-break')?'kitchen':s.balls[0].pocketed?'kitchen':null;
    s.phase='aiming';s.choice=null;s.message=s.ballInHand?'Place the cue ball behind the head string.':'Table accepted. Call your next shot.';return true;
  }
  spotEight() {
    const s=this.state;let x=750,y=250;
    while(s.balls.some(b=>b.id!==8&&!b.pocketed&&Math.hypot(b.x-x,b.y-y)<2*R+.1)) {x+=1;if(x>W-R){x=R;y+=R*2+1;}}
    Object.assign(s.balls.find(b=>b.id===8),ball(8,x,y));
  }
  snapshot(){return JSON.parse(JSON.stringify(this.state));}
  load(state){this.state=state;}
}
