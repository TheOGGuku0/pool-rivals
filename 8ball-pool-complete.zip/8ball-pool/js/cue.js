export function drawCue(ctx,cue,angle,power,anim=0,time=0) {
  ctx.save();ctx.translate(cue.x,cue.y);ctx.rotate(angle+Math.PI);
  const offset=18+power*66*(1-anim)-anim*14;
  ctx.translate(offset,0);ctx.shadowColor='#0008';ctx.shadowBlur=7;ctx.shadowOffsetY=4;
  const wood=ctx.createLinearGradient(0,-4,0,4);wood.addColorStop(0,'#e4c295');wood.addColorStop(.45,'#ffe1ae');wood.addColorStop(1,'#9f7141');
  ctx.beginPath();ctx.moveTo(0,-2.7);ctx.lineTo(290,-5);ctx.lineTo(290,5);ctx.lineTo(0,2.7);ctx.closePath();ctx.fillStyle=wood;ctx.fill();ctx.shadowBlur=0;
  ctx.fillStyle='#edf0e8';ctx.fillRect(0,-2.7,8,5.4);ctx.fillStyle='#53b1bd';ctx.fillRect(-3,-2.7,3,5.4);
  ctx.fillStyle='#243236';ctx.fillRect(192,-4.3,94,8.6);
  for(let x=195;x<284;x+=4){ctx.strokeStyle='#b2a79244';ctx.beginPath();ctx.moveTo(x,-4);ctx.lineTo(x+3,4);ctx.stroke();}
  ctx.fillStyle='#c3a66f';ctx.fillRect(187,-4.2,5,8.4);ctx.fillRect(282,-5,8,10);ctx.restore();
}
