import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {createPoolServer} from '../server.js';
class Client {
  constructor(url){this.ws=new WebSocket(url);this.messages=[];this.ws.addEventListener('message',e=>this.messages.push(JSON.parse(e.data)));}
  async open(){await once(this.ws,'open');return this;}
  send(m){this.ws.send(JSON.stringify(m));}
  async wait(predicate,timeout=4000){const start=Date.now();while(Date.now()-start<timeout){const index=this.messages.findIndex(predicate);if(index>=0)return this.messages.splice(index,1)[0];await new Promise(r=>setTimeout(r,10));}throw Error('Timed out waiting for room message');}
}
test('authoritative rooms: create, join, rejection, shot sync, reconnect, rematch, leave',async()=>{
  const app=createPoolServer();app.server.listen(0,'127.0.0.1');await once(app.server,'listening');const port=app.server.address().port,url=`ws://127.0.0.1:${port}/pool`;let a,b,c;
  try{
    const health=await fetch(`http://127.0.0.1:${port}/health`);assert.equal(health.status,200);assert.equal((await fetch(`http://127.0.0.1:${port}/server.js`)).status,404);
    a=await new Client(url).open();b=await new Client(url).open();a.send({type:'create',name:'Alice'});const joined=await a.wait(m=>m.type==='joined');b.send({type:'join',code:joined.code,name:'Bob'});const bob=await b.wait(m=>m.type==='joined');assert.equal(bob.seat,1);await a.wait(m=>m.type==='state'&&m.room.ready);
    b.send({type:'place',x:230,y:250});assert.match((await b.wait(m=>m.type==='error')).message,/rejected/);
    a.send({type:'place',x:230,y:250});await a.wait(m=>m.type==='state'&&!m.state.ballInHand);
    a.send({type:'shot',action:{angle:0,power:.05,spin:{x:0,y:0}}});const moving=await b.wait(m=>m.type==='state'&&m.state.phase==='moving');assert.equal(moving.state.shotNo,1);
    a.send({type:'shot',action:{angle:0,power:1,spin:{x:0,y:0}}});await a.wait(m=>m.type==='error');
    b.ws.close();await a.wait(m=>m.type==='state'&&!m.room.ready);c=await new Client(url).open();c.send({type:'resume',code:joined.code,token:bob.token});assert.equal((await c.wait(m=>m.type==='joined')).seat,1);await a.wait(m=>m.type==='state'&&m.room.ready);
    a.send({type:'rematch'});c.send({type:'rematch'});const fresh=await c.wait(m=>m.type==='state'&&m.state.shotNo===0&&m.state.starter===1);assert.equal(fresh.state.phase,'aiming');assert.equal(fresh.state.ballInHand,'kitchen');
    c.send({type:'leave'});const ended=await a.wait(m=>m.type==='state'&&m.state.phase==='over');assert.equal(ended.state.winner,0);
  }finally{a?.ws.close();b?.ws.close();c?.ws.close();app.stop();await new Promise(r=>app.server.close(r));}
});
